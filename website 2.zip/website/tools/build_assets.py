#!/usr/bin/env python3
"""PALIN · Assets bauen

Erzeugt aus den lesbaren Quelldateien die komprimierten Versionen, die die Seiten laden:
  css/style.css  ->  css/style.min.css
  js/main.js     ->  js/main.min.js
und trägt in allen HTML-Seiten eine neue Versionsnummer (?v=...) ein, damit Browser
die Änderungen sofort laden statt eine alte Kopie aus dem Zwischenspeicher zu zeigen.

Nach jeder Änderung an style.css oder main.js einmal ausführen:
    python3 tools/build_assets.py
"""
import hashlib, pathlib, re

SITE = pathlib.Path(__file__).resolve().parent.parent / "PALIN Website"


def minify_css(src: str) -> str:
    src = re.sub(r"/\*.*?\*/", "", src, flags=re.S)          # comments
    src = re.sub(r"\s+", " ", src)                               # whitespace runs
    src = re.sub(r"\s*([{};,>])\s*", r"\1", src)                 # around braces, semicolons, commas, child combinator
    src = re.sub(r":\s+", ":", src)                              # "color: red" -> "color:red" (never touches " :is()")
    src = src.replace(";}", "}")
    return src.strip() + "\n"


def minify_js(src: str) -> str:
    """Conservative: strips comments and indentation but keeps every line break,
    strings, template literals and regex literals untouched (no renaming)."""
    out, i, n = [], 0, len(src)
    prev_sig = ""  # last non-space character written, to tell a regex from a division
    while i < n:
        c = src[i]
        if c in "'\"`":                                          # string / template literal
            j = i + 1
            while j < n and src[j] != c:
                j += 2 if src[j] == "\\" else 1
            out.append(src[i:j + 1]); prev_sig = c; i = j + 1; continue
        if src.startswith("//", i):                              # line comment
            while i < n and src[i] != "\n":
                i += 1
            continue
        if src.startswith("/*", i):                              # block comment
            i = src.index("*/", i + 2) + 2; continue
        if c == "/" and (prev_sig == "" or prev_sig in "(,=:[!&|?{};+-*%<>~^"):  # regex literal
            j, in_class = i + 1, False
            while j < n:
                if src[j] == "\\": j += 2; continue
                if src[j] == "[": in_class = True
                elif src[j] == "]": in_class = False
                elif src[j] == "/" and not in_class: break
                j += 1
            j += 1
            while j < n and src[j].isalpha(): j += 1           # flags
            out.append(src[i:j]); prev_sig = "/"; i = j; continue
        out.append(c)
        if not c.isspace(): prev_sig = c
        i += 1
    lines = [ln.strip() for ln in "".join(out).split("\n")]
    return "\n".join(ln for ln in lines if ln) + "\n"


def main():
    css = (SITE / "css/style.css").read_text()
    js = (SITE / "js/main.js").read_text()
    css_min, js_min = minify_css(css), minify_js(js)
    (SITE / "css/style.min.css").write_text(css_min)
    (SITE / "js/main.min.js").write_text(js_min)
    extra = "".join((SITE / f).read_text() for f in ("css/clicker.css", "js/clicker.js") if (SITE / f).exists())
    version = hashlib.md5((css_min + js_min + extra).encode()).hexdigest()[:8]
    for page in SITE.glob("*.html"):
        html = page.read_text()
        new = re.sub(r"(css/style\.min\.css|js/main\.min\.js)\?v=[0-9a-f]+", rf"\1?v={version}", html)
        if new != html:
            page.write_text(new)
    print(f"style.min.css {len(css_min)//1024} KB (von {len(css)//1024} KB) · "
          f"main.min.js {len(js_min)//1024} KB (von {len(js)//1024} KB) · Version {version}")


if __name__ == "__main__":
    main()
