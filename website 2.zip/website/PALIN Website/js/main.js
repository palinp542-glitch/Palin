/* =========================================================
   PALIN · gemeinsames Script für alle Seiten
   ========================================================= */
(function(){
  var d = document;
  var ASSET_Q = (d.currentScript && d.currentScript.src.split('?')[1]) || '';
  d.documentElement.classList.add('js');
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
  // Handys/Tablets: weniger gleichzeitige Animationen, damit alles flüssig bleibt
  var small = matchMedia('(max-width: 760px)').matches || !fine;

  // Preise: Abo ist immer 5 € günstiger als der Einmalkauf, 30 Tabletten pro Dose
  var PRODUCTS = {
    essenties: {name:'Essenties', tag:'Daily Foundation', discover:'essenties.html', abo:24.95, once:29.95, img:'img/platzhalter/essenties.svg', url:'essenties-kaufen.html'},
    brainies:  {name:'Brainies', tag:'Focus Boost', discover:'brainies.html',  abo:29.95, once:34.95, img:'img/platzhalter/brainies.svg',  url:'brainies-kaufen.html'},
    sleepies:  {name:'Sleepies', tag:'Restful Nights', discover:'sleepies.html',  abo:19.95, once:24.95, img:'img/platzhalter/sleepies.svg',  url:'sleepies-kaufen.html'}
  };
  var PER_PACK = 30;
  // Preis pro Tag, kaufmännisch gerundet (19,95 € / 30 = 0,665 -> 0,67 €)
  function perDay(v){ return Math.round(v * 100 / PER_PACK) / 100 }
  function eur(n){ return n.toLocaleString('de-DE', {style:'currency', currency:'EUR'}) }

  /* ---------- one shared scroll loop: every scroll effect runs at most once per frame ---------- */
  // Positionen werden vorab gemessen statt bei jedem Scroll-Schritt (sonst muss der Browser
  // die Seite pro Bild mehrmals neu berechnen -> Ruckeln)
  function docTop(el){ var t = 0; while (el){ t += el.offsetTop; el = el.offsetParent } return t }
  var measureFns = [], vh = innerHeight, mTick = false;
  function remeasure(){ mTick = false; vh = innerHeight; for (var i = 0; i < measureFns.length; i++) measureFns[i]() }
  function scheduleMeasure(){ if (!mTick){ mTick = true; requestAnimationFrame(function(){ remeasure(); runScroll() }) } }
  addEventListener('resize', scheduleMeasure);
  addEventListener('load', scheduleMeasure);
  if (d.fonts && d.fonts.ready) d.fonts.ready.then(scheduleMeasure);
  if ('ResizeObserver' in window) new ResizeObserver(scheduleMeasure).observe(d.body);
  var onScrollFrame = [], sTick = false;
  function runScroll(){ sTick = false; for (var i = 0; i < onScrollFrame.length; i++) onScrollFrame[i]() }
  addEventListener('scroll', function(){ if (!sTick){ sTick = true; requestAnimationFrame(runScroll) } }, {passive:true});

  /* ---------- scroll lock shared by sheet + drawer ---------- */
  var locks = 0;
  function lock(on){ locks = Math.max(0, locks + (on ? 1 : -1)); d.documentElement.style.overflow = locks ? 'hidden' : '' }

  /* ---------- toast ---------- */
  var toast = d.createElement('div'), tt;
  toast.className = 'toast'; toast.setAttribute('role','status'); toast.setAttribute('aria-live','polite');
  d.body.appendChild(toast);
  function show(msg){ toast.textContent = msg; toast.classList.add('show'); clearTimeout(tt); tt = setTimeout(function(){ toast.classList.remove('show') }, 2600) }

  /* ---------- stars & shooting stars ---------- */
  // fester Zufall: jede Seite hat bei jedem Laden exakt denselben Sternenhimmel
  function seeded(seed){ return function(){ seed |= 0; seed = seed + 0x6D2B79F5 | 0; var t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296 } }
  var pageSeed = 0;
  for (var k = 0; k < location.pathname.length; k++) pageSeed = (pageSeed * 31 + location.pathname.charCodeAt(k)) | 0;
  d.querySelectorAll('.sky[data-stars]').forEach(function(sky, skyIndex){
    if (!sky.getClientRects().length) return;
    var Math = Object.create(window.Math); Math.random = seeded(pageSeed + (skyIndex + 1) * 7919);
    var n = Math.ceil(+sky.dataset.stars * (small ? .4 : .6)), i, s;
    for (i = 0; i < n; i++){
      s = d.createElement('span');
      var size = 4 + Math.random() * (i % 5 ? 6 : 13);
      s.className = 'star';
      s.style.cssText = 'left:'+(Math.random()*100)+'%;top:'+(Math.random()*100)+'%;width:'+size+'px;height:'+size+'px;animation-delay:-'+(Math.random()*6).toFixed(2)+'s;animation-duration:'+(4.5+Math.random()*4).toFixed(2)+'s';
      sky.appendChild(s);
    }
    for (i = 0; i < (small ? 0 : (+sky.dataset.shoot || 0)); i++){
      s = d.createElement('span');
      s.className = 'shoot';
      s.style.cssText = 'left:'+(55+Math.random()*50)+'%;top:'+(Math.random()*45)+'%;animation-delay:'+(2+i*4+Math.random()*3).toFixed(2)+'s;animation-duration:'+(11+Math.random()*6).toFixed(2)+'s';
      sky.appendChild(s);
    }
  });

  // Sternenhimmel und Schwebe-Animationen pausieren, solange ihr Bereich nicht sichtbar ist
  if ('IntersectionObserver' in window){
    var pio = new IntersectionObserver(function(en){
      en.forEach(function(e){ e.target.classList.toggle('off', !e.isIntersecting) });
    }, {rootMargin:'100px 0px'});
    d.querySelectorAll('.sky, .tile, .stage, .pcard').forEach(function(el){ pio.observe(el) });
  }

  /* ---------- sparkles (soft, slow) ---------- */
  var COLORS = ['#e9cf3c','#f4a9cb','#ffffff','#b99cff','#5fe0b0','#f0b43c'];
  function spark(x, y, o){
    if (reduce) return;
    o = o || {};
    for (var i = 0; i < (o.n || 12); i++) (function(i){
      var s = d.createElement('span'), size = (o.size || 9) * (.5 + Math.random());
      var a = Math.random() * Math.PI * 2, r = (o.r || 55) * (.4 + Math.random());
      var dx = Math.cos(a) * r, dy = Math.sin(a) * r + (o.fall || 24);
      s.className = 'spark';
      s.style.cssText = 'left:'+x+'px;top:'+y+'px;width:'+size+'px;height:'+size+'px;background:'+COLORS[(i + (Math.random()*6|0)) % COLORS.length];
      d.body.appendChild(s);
      s.animate([
        {transform:'translate(-50%,-50%) scale(0) rotate(0deg)', opacity:0},
        {transform:'translate(calc(-50% + '+dx*.5+'px),calc(-50% + '+dy*.5+'px)) scale(1) rotate(80deg)', opacity:1, offset:.3},
        {transform:'translate(calc(-50% + '+dx+'px),calc(-50% + '+dy+'px)) scale(.2) rotate(180deg)', opacity:0}
      ], {duration:1300 + Math.random()*700, easing:'cubic-bezier(.22,1,.36,1)'}).onfinish = function(){ s.remove() };
    })(i);
  }

  if (fine && !reduce){
    // pixie dust follows the cursor
    var last = 0;
    d.addEventListener('pointermove', function(e){
      var now = performance.now();
      if (now - last < 90) return;
      last = now;
      var s = d.createElement('span'), size = 3 + Math.random()*5;
      s.className = 'spark';
      s.style.cssText = 'left:'+e.clientX+'px;top:'+e.clientY+'px;width:'+size+'px;height:'+size+'px;background:'+COLORS[Math.random()*COLORS.length|0];
      d.body.appendChild(s);
      s.animate([
        {transform:'translate(-50%,-50%) scale(1)', opacity:.8},
        {transform:'translate(calc(-50% + '+(Math.random()*20-10)+'px),calc(-50% + '+(22+Math.random()*24)+'px)) scale(0) rotate(120deg)', opacity:0}
      ], {duration:1400, easing:'cubic-bezier(.22,1,.36,1)'}).onfinish = function(){ s.remove() };
    }, {passive:true});

    // a gentle burst when hovering something magical
    var magic = '.pill, .tilt, .plan, .feature, .opt, .thumbs button, .gnav .logo, .day li, .steps li';
    d.addEventListener('pointerover', function(e){
      var el = e.target.closest(magic);
      if (!el || el.contains(e.relatedTarget)) return;
      if (el._t && Date.now() - el._t < 1200) return;
      el._t = Date.now();
      spark(e.clientX, e.clientY, {n: el.matches('.tilt') ? 12 : 6, r: el.matches('.tilt') ? 80 : 40, size: 8});
    });

    // smooth 3D tilt (eased toward the pointer every frame)
    d.querySelectorAll('.tilt').forEach(function(el){
      var tx = 0, ty = 0, cx = 0, cy = 0, sc = 1, ts = 1, raf = 0;
      function loop(){
        cx += (tx - cx) * .08; cy += (ty - cy) * .08; sc += (ts - sc) * .08;
        el.style.transform = 'perspective(1000px) rotateX('+cy.toFixed(2)+'deg) rotateY('+cx.toFixed(2)+'deg) scale('+sc.toFixed(3)+')';
        raf = (Math.abs(tx - cx) + Math.abs(ty - cy) + Math.abs(ts - sc) > .01) ? requestAnimationFrame(loop) : 0;
      }
      function kick(){ if (!raf) raf = requestAnimationFrame(loop) }
      el.addEventListener('pointermove', function(e){
        var r = el.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        tx = (x - .5) * 12; ty = (.5 - y) * 10; ts = 1.03;
        el.style.setProperty('--mx', x*100+'%'); el.style.setProperty('--my', y*100+'%');
        kick();
      });
      el.addEventListener('pointerenter', function(){ el.style.willChange = 'transform' });
      el.addEventListener('pointerleave', function(){ tx = ty = 0; ts = 1; kick(); setTimeout(function(){ if (!raf) el.style.willChange = '' }, 1200) });
    });
  }

  /* ---------- nav: transparent over the hero, glass once you scroll ---------- */
  var nav = d.getElementById('gnav'), burger = d.getElementById('burger');
  var navScrolled = null;
  function onScroll(){ var sc = scrollY > 40; if (sc !== navScrolled){ navScrolled = sc; nav.classList.toggle('scrolled', sc) } }
  onScroll(); onScrollFrame.push(onScroll);
  // Produkte-Menü (Desktop: Hover oder Klick, Handy: im Menü aufgeklappt)
  var megaLi = d.querySelector('.has-mega'), megaBtn = megaLi && megaLi.querySelector('.menu-btn');
  function setMega(open){ if (!megaLi) return; megaLi.classList.toggle('mega-open', open); megaBtn.setAttribute('aria-expanded', open) }
  if (megaBtn){
    megaBtn.addEventListener('click', function(e){ e.stopPropagation(); setAcct(false); setMega(!megaLi.classList.contains('mega-open')) });
    if (fine){
      var megaT = 0;
      megaLi.addEventListener('pointerenter', function(){ clearTimeout(megaT); setAcct(false); setMega(true) });
      megaLi.addEventListener('pointerleave', function(){ megaT = setTimeout(function(){ setMega(false) }, 180) });
    }
  }
  // Konto-Icon: Anmelden, Bestellungen, Abo verwalten
  var acctBtn = d.getElementById('acctBtn'), acctPop = d.getElementById('acctPop');
  function setAcct(open){ if (!acctPop) return; acctPop.hidden = !open; acctBtn.setAttribute('aria-expanded', open); nav.classList.toggle('acct-open', open) }
  if (acctBtn) acctBtn.addEventListener('click', function(e){ e.stopPropagation(); setMega(false); setAcct(acctPop.hidden) });
  d.addEventListener('click', function(e){
    if (acctPop && !acctPop.hidden && !e.target.closest('#acctPop')) setAcct(false);
    if (megaLi && megaLi.classList.contains('mega-open') && !e.target.closest('.has-mega')) setMega(false);
  });
  d.addEventListener('keydown', function(e){ if (e.key === 'Escape'){ setAcct(false); setMega(false) } });
  function setMenu(open){ nav.classList.toggle('open', open); burger.setAttribute('aria-expanded', open); burger.setAttribute('aria-label', open ? 'Menü schließen' : 'Menü öffnen'); lock(open) }
  burger.addEventListener('click', function(){ setMenu(!nav.classList.contains('open')) });
  d.querySelectorAll('#menu a').forEach(function(a){ a.addEventListener('click', function(){ if (nav.classList.contains('open')) setMenu(false) }) });

  /* ---------- hero video + soft parallax ---------- */
  var hero = d.getElementById('hero'), v = d.getElementById('heroVideo'), vt = d.getElementById('videoToggle');
  if (hero && v){
    var userPaused = false, heroVisible = true;
    v.muted = true;                                       // iOS spielt nur stumme Videos automatisch ab
    function playSafe(){ var p = v.play(); if (p && p.catch) p.catch(function(){ hero.classList.add('paused') }) }
    playSafe();
    v.addEventListener('canplay', function(){ if (v.paused && heroVisible && !userPaused) playSafe() });
    // spart Akku und CPU: Video läuft nur, solange der Startbereich sichtbar ist
    if ('IntersectionObserver' in window){
      new IntersectionObserver(function(en){
        heroVisible = en[0].isIntersecting;
        if (!heroVisible && !v.paused) v.pause();
        else if (heroVisible && v.paused && !userPaused) playSafe();
      }).observe(hero);
    }
    v.addEventListener('loadeddata', function(){ hero.classList.add('has-video') });
    v.addEventListener('playing', function(){ hero.classList.add('playing'); hero.classList.remove('paused'); vt.setAttribute('aria-label','Video pausieren') });
    v.addEventListener('pause', function(){ hero.classList.add('paused'); vt.setAttribute('aria-label','Video abspielen') });
    vt.addEventListener('click', function(){ userPaused = !v.paused; v.paused ? playSafe() : v.pause() });
    if (!reduce && !small){
      var copy = hero.querySelector('.copy'), ticking = false, heroH = hero.offsetHeight;
      addEventListener('resize', function(){ heroH = hero.offsetHeight });
      onScrollFrame.push(function(){
        if (scrollY > heroH * 1.2){ if (ticking) return; ticking = true } else ticking = false;
        var y = Math.min(scrollY, heroH), p = y / heroH;
        copy.style.transform = 'translateY(' + (y * .3).toFixed(1) + 'px)';
        copy.style.opacity = (1 - p * 1.3).toFixed(3);
      });
    }
  }

  /* ---------- scroll reveal with a soft stagger ---------- */
  var els = d.querySelectorAll('.reveal');
  els.forEach(function(el){
    var sibs = Array.prototype.filter.call(el.parentNode.children, function(c){ return c.classList.contains('reveal') });
    var ms = Math.min(sibs.indexOf(el), 6) * 90;
    el.style.transitionDelay = ms + 'ms';
    el.style.animationDelay = ms + 'ms';
    el.style.setProperty('--d', ms + 'ms');
  });
  if ('IntersectionObserver' in window){
    var io = new IntersectionObserver(function(entries){
      entries.forEach(function(e){ if (e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target) } });
    }, {rootMargin:'0px 0px -6% 0px'});
    els.forEach(function(el){ io.observe(el) });
  } else {
    els.forEach(function(el){ el.classList.add('in') });
  }

  /* ---------- headline animations: only key headlines, each with its own effect ---------- */
  // Text in Wörter (rise, flip) bzw. Buchstaben (letters) zerlegen, verschachtelte Spans wie .grad bleiben erhalten
  function splitText(el, mode){
    var i = 0;
    (function walk(node){
      Array.prototype.slice.call(node.childNodes).forEach(function(n){
        if (n.nodeType === 1){ walk(n); return }
        if (n.nodeType !== 3) return;
        var frag = d.createDocumentFragment();
        n.textContent.split(/(\s+)/).forEach(function(part){
          if (!part) return;
          if (/^\s+$/.test(part)){ frag.appendChild(d.createTextNode(part)); return }
          if (mode === 'letters'){
            var wd = d.createElement('span'); wd.className = 'wd';
            Array.from(part).forEach(function(ch){
              var c = d.createElement('span'); c.className = 'ch'; c.textContent = ch; c.style.setProperty('--i', i++); wd.appendChild(c);
            });
            frag.appendChild(wd);
          } else {
            var wi = d.createElement('span'); wi.className = 'wi'; wi.textContent = part; wi.style.setProperty('--i', i++);
            if (mode === 'rise'){ var wm = d.createElement('span'); wm.className = 'wm'; wm.appendChild(wi); frag.appendChild(wm) }
            else frag.appendChild(wi);
          }
        });
        n.parentNode.replaceChild(frag, n);
      });
    })(el);
  }
  var animEls = d.querySelectorAll('[data-anim]');
  animEls.forEach(function(el){
    var m = el.dataset.anim;
    if (m === 'rise' || m === 'flip' || m === 'letters') splitText(el, m);
    else if (m === 'type') splitText(el, 'letters');
    else if (m === 'twinkle'){
      splitText(el, 'words');
      el.querySelectorAll('.wi').forEach(function(w, i){ w.style.setProperty('--r', ((i * 0.37) % 1).toFixed(2)) });
    }
  });
  // Lifestyle-Bilder öffnen sich beim Reinscrollen
  animEls = Array.prototype.slice.call(animEls).concat(Array.prototype.slice.call(d.querySelectorAll('.story-media')));
  if ('IntersectionObserver' in window){
    var aio = new IntersectionObserver(function(en){
      en.forEach(function(e){ if (e.isIntersecting){ e.target.classList.add('go'); aio.unobserve(e.target) } });
    }, {rootMargin:'0px 0px 8% 0px'});
    animEls.forEach(function(el){ aio.observe(el) });
  } else animEls.forEach(function(el){ el.classList.add('go') });

  /* ---------- discover page: highlights carousel with dots + play/pause (like Apple) ---------- */
  d.querySelectorAll('.hl-track').forEach(function(track){
    var cards = Array.prototype.slice.call(track.children), dotsWrap = track.parentNode.querySelector('.hl-dots'), play = track.parentNode.querySelector('.hl-play');
    var idx = 0, timer = 0, paused = false, visible = false;
    var dots = cards.map(function(c, i){
      var b = d.createElement('button'); b.type = 'button'; b.setAttribute('aria-label', 'Highlight ' + (i + 1));
      b.addEventListener('click', function(){ stop(true); go(i) });
      dotsWrap.appendChild(b); return b;
    });
    function go(i){ idx = (i + cards.length) % cards.length; track.scrollTo({left: cards[idx].offsetLeft - cards[0].offsetLeft, behavior: 'smooth'}) }
    function mark(){
      var best = 0, bd = 1e9;
      cards.forEach(function(c, i){ var dd = Math.abs(c.offsetLeft - cards[0].offsetLeft - track.scrollLeft); if (dd < bd){ bd = dd; best = i } });
      idx = best; dots.forEach(function(b, i){ b.setAttribute('aria-current', i === best) });
    }
    function tick(){ clearTimeout(timer); if (!paused && visible) timer = setTimeout(function(){ go(idx + 1); tick() }, 4500) }
    function stop(user){ paused = true; clearTimeout(timer); play.classList.add('paused'); play.setAttribute('aria-label', 'Automatisch weiterblättern') }
    play.addEventListener('click', function(){
      if (paused){ paused = false; play.classList.remove('paused'); play.setAttribute('aria-label', 'Automatisches Weiterblättern pausieren'); go(idx + 1); tick() }
      else stop(true);
    });
    track.addEventListener('pointerdown', function(){ stop(true) });
    track.addEventListener('wheel', function(e){ if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) stop(true) }, {passive:true});
    var tt = false;
    track.addEventListener('scroll', function(){ if (!tt){ tt = true; requestAnimationFrame(function(){ tt = false; mark() }) } }, {passive:true});
    new IntersectionObserver(function(en){ visible = en[0].isIntersecting; tick() }, {threshold:.4}).observe(track);
    mark();
  });

  // Karten-Reihen mit Pfeilen (Apple-Stil)
  d.querySelectorAll('.rail[data-arrows]').forEach(function(rail){
    var nav = rail.nextElementSibling, prev = nav.querySelector('[data-dir="-1"]'), next = nav.querySelector('[data-dir="1"]');
    function step(){ var c = rail.children[0]; return c ? c.getBoundingClientRect().width + 16 : 300 }
    function upd(){ prev.disabled = rail.scrollLeft < 8; next.disabled = rail.scrollLeft + rail.clientWidth > rail.scrollWidth - 8 }
    nav.querySelectorAll('button').forEach(function(b){ b.addEventListener('click', function(){ rail.scrollBy({left: step() * +b.dataset.dir, behavior: reduce ? 'auto' : 'smooth'}) }) });
    rail.addEventListener('scroll', upd, {passive:true}); addEventListener('resize', upd); upd();
  });

  // Zahlen zählen hoch, sobald sie ins Bild kommen
  var counters = d.querySelectorAll('[data-count]');
  if (counters.length && 'IntersectionObserver' in window){
    var cio = new IntersectionObserver(function(en){
      en.forEach(function(e){
        if (!e.isIntersecting) return; cio.unobserve(e.target);
        var el = e.target, to = parseFloat(el.dataset.count), dec = +el.dataset.dec, suf = el.dataset.suffix || '', t0 = performance.now(), dur = reduce ? 1 : 1200;
        (function f(now){
          var p = Math.min(1, (now - t0) / dur), v = to * (1 - Math.pow(1 - p, 3));
          el.textContent = v.toFixed(dec).replace('.', ',') + suf;
          if (p < 1) requestAnimationFrame(f);
        })(t0);
      });
    }, {threshold:.6});
    counters.forEach(function(c){ cio.observe(c) });
  }

  /* ---------- statement: words light up one after another while scrolling ---------- */
  var st = d.querySelector('.statement');
  if (st){
    var words = [];
    st.querySelectorAll('p.words').forEach(function wrap(node){
      Array.prototype.slice.call(node.childNodes).forEach(function(n){
        if (n.nodeType === 3){
          var frag = d.createDocumentFragment();
          n.textContent.split(/(\s+)/).forEach(function(part){
            if (!part) return;
            if (/^\s+$/.test(part)){ frag.appendChild(d.createTextNode(part)); return }
            var w = d.createElement('span'); w.className = 'w'; w.textContent = part; words.push(w); frag.appendChild(w);
          });
          n.parentNode.replaceChild(frag, n);
        } else if (n.nodeType === 1) wrap(n);
      });
    });
    var stTick = false;
    var stTop = 0;
    measureFns.push(function(){ stTop = docTop(st) });
    function lightWords(){
      stTick = false;
      var r = {top: stTop - scrollY};
      var prog = Math.max(0, Math.min(1, (vh * .95 - r.top) / (vh * .4)));
      var lit = Math.round(prog * words.length);
      words.forEach(function(w, i){
        var on = i < lit;
        if (on !== w.classList.contains('lit')){
          w.classList.toggle('lit', on);
          var g = w.closest('.grad');
          if (g && on && w === g.querySelector('.w:last-child')){ g.classList.remove('pop'); void g.offsetWidth; g.classList.add('pop') }
        }
      });
    }
    onScrollFrame.push(lightWords);
    stTop = docTop(st); lightWords();
  }

  /* ---------- product images grow into place with the scroll ---------- */
  var zooms = d.querySelectorAll('.zoom');
  if (zooms.length && !reduce && !small){
    var zTick = false, active = new Set();
    var zio = new IntersectionObserver(function(en){
      en.forEach(function(e){ e.isIntersecting ? active.add(e.target) : active.delete(e.target) });
      zoomAll();
    }, {rootMargin:'10% 0px'});
    zooms.forEach(function(el){ zio.observe(el) });
    function zoomAll(){
      zTick = false;
      var list = Array.from(active);
      var tops = list.map(function(el){ return (el._top || (el._top = docTop(el))) - scrollY });
      list.forEach(function(el, i){
        var p = Math.max(0, Math.min(1, (vh - tops[i]) / (vh * .65)));
        var e = 1 - Math.pow(1 - p, 3);
        el.style.transform = 'translateY(' + ((1 - e) * 60).toFixed(1) + 'px) scale(' + (.78 + .22 * e).toFixed(3) + ') rotate(' + ((1 - e) * -6).toFixed(2) + 'deg)';
        el.style.opacity = (.3 + .7 * e).toFixed(3);
      });
    }
    onScrollFrame.push(function(){ if (active.size) zoomAll() });
    measureFns.push(function(){ zooms.forEach(function(el){ el._top = docTop(el) }) });
  }

  /* ---------- cart (kept in this browser across pages) ---------- */
  var KEY = 'palin-cart', cart = [];
  try { cart = JSON.parse(localStorage.getItem(KEY)) || [] } catch(e){ cart = [] }
  cart = cart.filter(function(it){ return PRODUCTS[it.id] });
  function save(){ try { localStorage.setItem(KEY, JSON.stringify(cart)) } catch(e){} }
  function unit(it){ return PRODUCTS[it.id][it.plan === 'abo' ? 'abo' : 'once'] }

  var drawer = d.createElement('div');
  drawer.className = 'drawer'; drawer.id = 'drawer';
  drawer.innerHTML =
    '<div class="scrim" data-close></div>' +
    '<aside class="panel" tabindex="-1" role="dialog" aria-modal="true" aria-labelledby="drawerTitle">' +
      '<header><h2 id="drawerTitle">Warenkorb</h2>' +
      '<button class="icon-btn close" type="button" data-close aria-label="Warenkorb schließen"><svg width="16" height="16" viewBox="0 0 16 16" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M3 3l10 10M13 3L3 13"/></svg></button></header>' +
      '<div class="items" id="cartItems"></div>' +
      '<div class="sum" id="cartSum"></div>' +
    '</aside>';
  d.body.appendChild(drawer);
  var ICON_BOX = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.8 20.5 7v10L12 21.2 3.5 17V7z"/><path d="M3.5 7 12 11.2 20.5 7M12 11.2v10"/></svg>';
  var ICON_REPEAT = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 2.5 20.5 6 17 9.5"/><path d="M3.5 11.5V10a4 4 0 0 1 4-4h13"/><path d="M7 21.5 3.5 18 7 14.5"/><path d="M20.5 12.5V14a4 4 0 0 1-4 4h-13"/></svg>';
  var ICON_USER = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="12" r="9.5"/><circle cx="12" cy="10" r="3.2"/><path d="M6.2 18.4c1.3-2.3 3.4-3.4 5.8-3.4s4.5 1.1 5.8 3.4" stroke-linecap="round"/></svg>';
  var itemsEl = d.getElementById('cartItems'), sumEl = d.getElementById('cartSum'), bagN = d.getElementById('cartN'), bag = d.getElementById('cartBtn'), lastFocus;

  function render(){
    // Zwischensumme = regulärer Preis ohne Abo, davon wird die Abo-Ersparnis abgezogen
    var count = 0, regular = 0, saved = 0;
    cart.forEach(function(it){ count += it.qty; regular += PRODUCTS[it.id].once * it.qty; if (it.plan === 'abo') saved += (PRODUCTS[it.id].once - PRODUCTS[it.id].abo) * it.qty });
    var total = regular - saved;
    bagN.textContent = count || '';
    // Produkte, die noch nicht im Warenkorb liegen -> "Das könnte dir auch gefallen"
    var inCart = {}; cart.forEach(function(it){ inCart[it.id] = true });
    var recos = Object.keys(PRODUCTS).filter(function(k){ return !inCart[k] });
    var recoHTML = recos.length ? '<section class="reco" aria-label="Das könnte dir auch gefallen"><p class="drawer-label">' + (cart.length ? 'Das könnte dir auch gefallen' : 'Unsere Sorten') + '</p>' +
      recos.map(function(k){
        var p = PRODUCTS[k];
        return '<div class="reco-item"><a href="'+p.discover+'"><img src="'+p.img+'" alt=""></a>' +
          '<div class="meta"><span class="reco-tag">'+p.tag+'</span><b>'+p.name+'</b><span>ab '+eur(perDay(p.abo))+' pro Tag</span></div>' +
          '<button type="button" class="pill soft reco-add" data-reco="'+k+'">Hinzufügen</button></div>';
      }).join('') + '</section>' : '';
    if (!cart.length){
      itemsEl.innerHTML = '<div class="empty"><b>Dein Warenkorb ist leer.</b><span><a href="konto.html#anmelden">Melde dich an</a>, um deine Bestellungen und Abos zu sehen.</span></div>' + recoHTML;
      sumEl.hidden = true;
      sumEl.innerHTML = '';
      return;
    }
    sumEl.hidden = false;
    itemsEl.innerHTML = cart.map(function(it, i){
      var p = PRODUCTS[it.id], abo = it.plan === 'abo';
      // kleines Feld pro Produkt: Abo oder Einmalkauf (bei Abo mit Rhythmus)
      var planSw = '<div class="plan-sw" role="group" aria-label="Kaufart für ' + p.name + '">' +
          '<button type="button" data-plan="' + i + ':abo" aria-pressed="' + abo + '">Abo</button>' +
          '<button type="button" data-plan="' + i + ':once" aria-pressed="' + !abo + '">Einmal</button></div>' +
        (abo ? '<select class="plan-int" data-int="' + i + '" aria-label="Lieferrhythmus">' + [30, 45, 60].map(function(n){ return '<option value="' + n + '"' + (n === it.interval ? ' selected' : '') + '>alle ' + n + ' Tage</option>' }).join('') + '</select>' : '');
      return '<div class="item">' +
        '<a href="'+p.url+'"><img src="'+p.img+'" alt=""></a>' +
        '<div class="meta"><b>'+p.name+'</b><div class="plan-row">' + planSw + '</div>' +
          '<div class="qty"><button type="button" data-dec="'+i+'" aria-label="Weniger">−</button><output>'+it.qty+'</output><button type="button" data-inc="'+i+'" aria-label="Mehr">+</button></div></div>' +
        '<div class="right"><b>'+eur(unit(it) * it.qty)+'</b><button type="button" class="link" data-rm="'+i+'">Entfernen</button></div>' +
      '</div>';
    }).join('') + recoHTML;
    sumEl.innerHTML =
      '<div class="row"><span>Zwischensumme</span><span>'+eur(regular)+'</span></div>' +
      (saved ? '<div class="row save"><span>Deine Abo-Ersparnis</span><span>−'+eur(saved)+'</span></div>' : '') +
      '<div class="row total"><span>Gesamt</span><span>'+eur(total)+'</span></div>' +
      '<button class="pill big magic" type="button" id="checkout">Zur Kasse</button>' +
      '<small>inkl. MwSt., zzgl. Versand · Abo jederzeit kündbar</small>';
  }

  function add(item, from){
    var hit = cart.filter(function(it){ return it.id === item.id && it.plan === item.plan && it.interval === item.interval })[0];
    hit ? hit.qty += item.qty : cart.push(item);
    save(); render();
    bag.classList.remove('bump'); void bag.offsetWidth; bag.classList.add('bump');
    if (from){ var r = from.getBoundingClientRect(); spark(r.left + r.width/2, r.top + r.height/2, {n:18, r:90}) }
    setTimeout(openCart, reduce ? 0 : 500);
  }

  function openCart(){ if (drawer.classList.contains('open')) return; lastFocus = d.activeElement; drawer.classList.add('open'); lock(true); drawer.querySelector('.panel').focus({preventScroll:true}) }
  function closeCart(){ if (!drawer.classList.contains('open')) return; drawer.classList.remove('open'); lock(false); if (lastFocus) lastFocus.focus() }
  bag.addEventListener('click', openCart);
  drawer.addEventListener('click', function(e){
    var link = e.target.closest('a[href]');
    if (link && !link.hasAttribute('data-close')){ drawer.classList.remove('open'); lock(false); return }
    var t = e.target.closest('button, a, .scrim');
    if (!t) return;
    if (t.hasAttribute('data-close')) return closeCart();
    if (t.dataset.reco){ return openSheet(t.dataset.reco, 1) }
    if (t.dataset.inc){ cart[+t.dataset.inc].qty++ }
    else if (t.dataset.dec){ var it = cart[+t.dataset.dec]; if (--it.qty < 1) cart.splice(+t.dataset.dec, 1) }
    else if (t.dataset.rm){ cart.splice(+t.dataset.rm, 1) }
    else if (t.dataset.plan){
      var parts = t.dataset.plan.split(':'), idx = +parts[0], it2 = cart[idx];
      if (it2.plan === parts[1]) return;
      setLine(idx, parts[1], parts[1] === 'abo' ? (it2.interval || 30) : 0);
      return;
    }
    else if (t.id === 'checkout'){ return show('Die Kasse öffnet zum Launch') }
    else return;
    save(); render();
  });
  drawer.addEventListener('change', function(e){
    var sel = e.target.closest('[data-int]');
    if (sel) setLine(+sel.dataset.int, 'abo', +sel.value);
  });
  // eine Warenkorb-Zeile auf Abo/Einmal bzw. einen anderen Rhythmus umstellen; gleiche Zeilen werden zusammengelegt
  function setLine(idx, plan, interval){
    var it = cart.splice(idx, 1)[0];
    var hit = cart.filter(function(x){ return x.id === it.id && x.plan === plan && x.interval === interval })[0];
    if (hit) hit.qty += it.qty; else cart.splice(idx, 0, {id:it.id, plan:plan, interval:interval, qty:it.qty});
    save(); render();
  }
  render();

  /* ---------- purchase sheet: Abo or Einmalkauf, chosen before the cart ---------- */
  var sheet = d.createElement('div'), sheetState = null;
  sheet.className = 'sheet'; sheet.id = 'sheet';
  sheet.innerHTML =
    '<div class="scrim" data-sclose></div>' +
    '<div class="sheet-panel" tabindex="-1" role="dialog" aria-modal="true" aria-labelledby="sheetTitle">' +
      '<span class="grab" aria-hidden="true"></span>' +
      '<header class="sheet-head"><img id="sheetImg" src="" alt=""><div><p class="eyebrow" id="sheetName">Fast geschafft</p><h2 id="sheetTitle">Abo oder einmal?</h2></div>' +
        '<button class="icon-btn close" type="button" data-sclose aria-label="Schließen"><svg width="16" height="16" viewBox="0 0 16 16" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M3 3l10 10M13 3L3 13"/></svg></button></header>' +
      '<form id="sheetForm">' +
        '<fieldset class="opts"><legend class="sr">Kaufoption wählen</legend>' +
          '<label class="opt"><input type="radio" name="plan" value="abo" checked>' +
            '<span class="opt-head"><span class="radio"></span><span class="opt-title">Abo &amp; sparen <em class="badge">Empfohlen</em></span>' +
            '<span class="opt-price"><s data-p="once"></s><b data-p="abo"></b><small data-p="aboDay"></small></span></span>' +
            '<span class="opt-body"><ul class="checks"><li>5 € sparen bei jeder Lieferung</li><li>Alle 30, 45 oder 60 Tage</li><li>Pausieren oder kündigen, jederzeit</li></ul>' +
            '<span class="interval">Lieferung <select name="interval" aria-label="Lieferrhythmus"><option value="30" selected>alle 30 Tage (empfohlen)</option><option value="45">alle 45 Tage</option><option value="60">alle 60 Tage</option></select></span></span>' +
          '</label>' +
          '<label class="opt"><input type="radio" name="plan" value="once">' +
            '<span class="opt-head"><span class="radio"></span><span class="opt-title">Einmalkauf</span>' +
            '<span class="opt-price"><b data-p="onceB"></b><small data-p="onceDay"></small></span></span>' +
          '</label>' +
        '</fieldset>' +
        '<button class="pill big magic" type="submit">Hinzufügen · <span data-p="total"></span></button>' +
        '<p class="fine">inkl. MwSt., zzgl. Versand</p>' +
      '</form>' +
    '</div>';
  d.body.appendChild(sheet);
  var sForm = d.getElementById('sheetForm');
  function sp(k){ return sheet.querySelector('[data-p="'+k+'"]') }
  function sheetUpdate(){
    var P = PRODUCTS[sheetState.id], q = sheetState.qty, abo = sForm.plan.value === 'abo';
    sp('once').textContent = eur(P.once * q);
    sp('abo').textContent = eur(P.abo * q);
    sp('aboDay').textContent = eur(perDay(P.abo)) + ' pro Tag';
    sp('onceB').textContent = eur(P.once * q);
    sp('onceDay').textContent = eur(perDay(P.once)) + ' pro Tag';
    sp('total').textContent = eur((abo ? P.abo : P.once) * q);
  }
  function openSheet(id, qty){
    // Liegt schon etwas im Warenkorb, wird die dort gewählte Variante (Abo inkl. Rhythmus oder Einmalkauf)
    // übernommen – ohne erneut zu fragen. Nur beim ersten Produkt erscheint die Auswahl.
    if (cart.length){
      var prev = cart[cart.length - 1], isAbo = prev.plan === 'abo';
      add({id:id, plan:prev.plan, interval: isAbo ? prev.interval : 0, qty: qty || 1}, d.activeElement && d.activeElement !== d.body ? d.activeElement : null);
      show(PRODUCTS[id].name + ' hinzugefügt · ' + (isAbo ? 'Abo, alle ' + prev.interval + ' Tage' : 'Einmalkauf'));
      return;
    }
    sheetState = {id:id, qty:qty || 1};
    var P = PRODUCTS[id];
    d.getElementById('sheetName').textContent = P.name + (sheetState.qty > 1 ? ' · ' + sheetState.qty + '×' : '');
    d.getElementById('sheetImg').src = P.img;
    sForm.plan.value = 'abo'; sForm.interval.value = '30';
    sheetUpdate();
    lastFocus = d.activeElement;
    sheet.classList.add('open'); lock(true);
    setTimeout(function(){ sheet.querySelector('.sheet-panel').focus({preventScroll:true}) }, 60);
  }
  function closeSheet(keepFocus){ if (!sheet.classList.contains('open')) return; sheet.classList.remove('open'); lock(false); if (!keepFocus && lastFocus) lastFocus.focus() }
  sForm.addEventListener('change', sheetUpdate);
  sForm.addEventListener('submit', function(e){
    e.preventDefault();
    var abo = sForm.plan.value === 'abo', btn = sForm.querySelector('[type=submit]');
    var r = btn.getBoundingClientRect();
    spark(r.left + r.width/2, r.top + r.height/2, {n:18, r:90});
    closeSheet(true);
    add({id:sheetState.id, plan: abo ? 'abo' : 'once', interval: abo ? +sForm.interval.value : 0, qty:sheetState.qty});
  });
  sheet.addEventListener('click', function(e){ if (e.target.closest('[data-sclose]')) closeSheet() });
  d.addEventListener('click', function(e){
    var b = e.target.closest('[data-buy]');
    if (b){ e.preventDefault(); openSheet(b.dataset.buy, 1) }
  });
  d.addEventListener('keydown', function(e){
    if (e.key !== 'Escape') return;
    if (sheet.classList.contains('open')) closeSheet();
    else if (drawer.classList.contains('open')) closeCart();
    else if (nav.classList.contains('open')) setMenu(false);
  });

  /* ---------- Easter Egg: Palins Zauberküche ---------- */
  // Geheim: 3× schnell auf den Zauberer unten auf der Startseite tippen – oder auf dem Desktop "palin" tippen.
  window.PALIN = {spark: spark, show: show};
  var eggLoading = false;
  function openEgg(){
    if (window.PalinClicker) return window.PalinClicker.open();
    if (eggLoading) return; eggLoading = true;
    var css = d.createElement('link'); css.rel = 'stylesheet'; css.href = 'css/clicker.css?' + ASSET_Q; d.head.appendChild(css);
    var js = d.createElement('script'); js.src = 'js/clicker.js?' + ASSET_Q;
    js.onload = function(){ eggLoading = false; setTimeout(function(){ window.PalinClicker.open() }, 60) };
    d.body.appendChild(js);
  }
  var wizard = d.querySelector('.t-night .media img'), taps = [];
  if (wizard) wizard.addEventListener('click', function(e){
    var now = Date.now(); taps = taps.filter(function(t){ return now - t < 1500 }); taps.push(now);
    spark(e.clientX, e.clientY, {n: 4 + taps.length * 3, r: 30 + taps.length * 15, size: 7});
    if (taps.length >= 3){ taps = []; openEgg() }
  });
  var typed = '';
  d.addEventListener('keydown', function(e){
    if (e.target.closest && e.target.closest('input, textarea, select')) return;
    if (!e.key || e.key.length !== 1) return;
    typed = (typed + e.key.toLowerCase()).slice(-5);
    if (typed === 'palin'){ typed = ''; openEgg() }
  });

  /* ---------- newsletter (homepage) ---------- */
  var nl = d.getElementById('newsletter');
  if (nl) nl.addEventListener('submit', function(e){
    e.preventDefault();
    var mail = nl.email.value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(mail)){ nl.email.focus(); return show('Bitte gib eine gültige E-Mail-Adresse ein.') }
    // TODO: hier den Newsletter-Anbieter anbinden (z. B. Brevo oder Mailchimp, mit Double-Opt-in)
    var r = nl.querySelector('button').getBoundingClientRect();
    spark(r.left + r.width / 2, r.top + r.height / 2, {n:16, r:80});
    nl.reset();
    show('Danke! Der Newsletter startet zum Launch.');
  });

  /* ---------- account page (preview until launch) ---------- */
  var loginForm = d.getElementById('loginForm');
  if (loginForm) loginForm.addEventListener('submit', function(e){ e.preventDefault(); show('Anmelden ist ab dem Shop-Launch möglich.') });

  /* ---------- product page: gallery, quantity, sticky bar ---------- */
  var form = d.getElementById('buyForm');
  if (form){
    var id = form.dataset.product, qty = 1, qtyOut = form.querySelector('.qty output');
    form.querySelectorAll('[data-q]').forEach(function(b){
      b.addEventListener('click', function(){ qty = Math.max(1, Math.min(9, qty + +b.dataset.q)); qtyOut.textContent = qty });
    });
    form.addEventListener('submit', function(e){ e.preventDefault(); openSheet(id, qty) });
    var lnavBuy = d.getElementById('lnavBuy');
    if (lnavBuy) lnavBuy.addEventListener('click', function(){ openSheet(id, qty) });
    // Kaufleiste oben erscheint erst, wenn der große Kaufen-Button aus dem Bild gescrollt ist
    var lnavBar = d.getElementById('lnavBar'), barShown = null;
    if (lnavBar){
      var buyBtn = form.querySelector('[type=submit]');
      var buyBottom = docTop(buyBtn) + buyBtn.offsetHeight;
      measureFns.push(function(){ buyBottom = docTop(buyBtn) + buyBtn.offsetHeight });
      function lnavCheck(){
        var show = scrollY > buyBottom;
        if (show !== barShown){ barShown = show; lnavBar.classList.toggle('show', show) }
      }
      onScrollFrame.push(lnavCheck); lnavCheck();
    }

    var bar = d.getElementById('buybar');
    if (bar){
      d.body.classList.add('has-buybar');
      bar.querySelector('button').addEventListener('click', function(){ openSheet(id, qty) });
      // erst sichtbar, sobald der Bereich unter dem Kaufbereich ("Warum …") beginnt
      var start = d.querySelector('main .tiles'), barTick = false;
      function barCheck(){
        barTick = false;
        bar.classList.toggle('show', start.getBoundingClientRect().top < innerHeight * .55);
      }
      onScrollFrame.push(barCheck);
      barCheck();
    }

  }
})();
