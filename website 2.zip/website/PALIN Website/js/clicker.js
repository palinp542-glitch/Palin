/* =========================================================
   PALIN · Easter Egg: "Palins Zauberküche" (Cookie-Clicker)
   Wird erst geladen, wenn jemand das Geheimnis entdeckt:
   3× schnell auf den Zauberer unten auf der Startseite tippen
   oder auf dem Desktop "palin" tippen.
   ========================================================= */
(function(){
  var d = document, P = window.PALIN || {}, KEY = 'palin-zauberkueche';
  var spark = P.spark || function(){}, toast = P.show || function(){};

  var ICON = {
    stab: '<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M8 33 27 14" stroke="#f1e8d8" stroke-width="4" stroke-linecap="round"/><path d="M8 33l4-4" stroke="#140a1c" stroke-width="4" stroke-linecap="round"/><path d="M30 4l1.8 4.7L36.5 10l-4.7 1.8L30 16.5l-1.8-4.7L23.5 10l4.7-1.3z" fill="#e9cf3c"/></svg>',
    hut: '<svg viewBox="0 0 40 40" aria-hidden="true"><rect x="12" y="6" width="16" height="20" rx="2" fill="#ff5c9d"/><rect x="6" y="25" width="28" height="7" rx="3.5" fill="#ff5c9d"/><rect x="12" y="20" width="16" height="3" fill="#c21a5c"/></svg>',
    kessel: '<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M9 18h22c0 9-5 15-11 15S9 27 9 18z" fill="#2a1638" stroke="#b99cff" stroke-width="2"/><path d="M7 18h26" stroke="#b99cff" stroke-width="2.5" stroke-linecap="round"/><circle cx="15" cy="11" r="3.5" fill="#b99cff" opacity=".7"/><circle cx="23" cy="8" r="4.5" fill="#b99cff" opacity=".5"/><circle cx="27" cy="13" r="2.5" fill="#b99cff" opacity=".8"/></svg>',
    mond: '<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M25 6a14 14 0 1 0 9 22A11 11 0 1 1 25 6z" fill="#f5c330"/><path d="M31 8l1 2.6 2.6 1-2.6 1-1 2.6-1-2.6-2.6-1 2.6-1z" fill="#fff"/></svg>'
  };
  var UP = [
    {id:'stab',  name:'Zauberstab',       desc:'+1 Essenties pro Klick',              base:15,     click:1, icon:ICON.stab},
    {id:'brain', name:'Brainies',         desc:'Denken mit: +1 pro Sekunde',           base:50,     rate:1,  img:'img/platzhalter/brainies.svg'},
    {id:'sleep', name:'Sleepies',         desc:'Zaubern im Schlaf: +6 pro Sekunde',    base:320,    rate:6,  img:'img/platzhalter/sleepies.svg'},
    {id:'hut',   name:'Zylinderhut',      desc:'Jeder Klick zählt doppelt',            base:1200,   mult:2,  once:true, icon:ICON.hut},
    {id:'kessel',name:'Zauberkessel',     desc:'Braut +40 pro Sekunde',                base:2800,   rate:40, icon:ICON.kessel},
    {id:'mond',  name:'Mondlicht',        desc:'+250 pro Sekunde',                     base:24000,  rate:250, icon:ICON.mond},
    {id:'palin', name:'Palin persönlich', desc:'Der Meister zaubert mit: +1.500 pro Sekunde', base:180000, rate:1500, img:'img/platzhalter/palin.svg'}
  ];
  var MILES = [[100,'Die ersten 100! Der Kessel wird warm.'],[1000,'1.000 Essenties. Palin nickt anerkennend.'],[10000,'10.000! Das riecht nach Cheesecake.'],[100000,'100.000. Du bist offiziell Zauberlehrling.'],[1000000,'Eine Million! Palin zieht den Hut vor dir.'],[10000000,'10 Millionen. Jetzt zauberst du Palin etwas vor.']];

  var st = {n:0, total:0, own:{}, miles:0};
  try { var saved = JSON.parse(localStorage.getItem(KEY)); if (saved) st = Object.assign(st, saved) } catch(e){}
  function save(){ try { localStorage.setItem(KEY, JSON.stringify(st)) } catch(e){} }

  function own(id){ return st.own[id] || 0 }
  function cost(u){ return Math.ceil(u.base * Math.pow(1.15, own(u.id))) }
  var boostUntil = 0;
  function boost(){ return Date.now() < boostUntil ? 7 : 1 }
  function perClick(){ return (1 + own('stab')) * (own('hut') ? 2 : 1) * boost() }
  function perSec(){ var r = 0; UP.forEach(function(u){ if (u.rate) r += u.rate * own(u.id) }); return r * boost() }
  function fmt(x){
    x = Math.floor(x);
    if (x < 100000) return x.toLocaleString('de-DE');
    var units = [[1e9,' Mrd.'],[1e6,' Mio.'],[1e3,' Tsd.']];
    for (var i = 0; i < units.length; i++) if (x >= units[i][0]) return (x / units[i][0]).toLocaleString('de-DE', {maximumFractionDigits: 1}) + units[i][1];
    return String(x);
  }

  /* ---------- UI ---------- */
  var root = d.createElement('div');
  root.className = 'pc'; root.setAttribute('role', 'dialog'); root.setAttribute('aria-modal', 'true'); root.setAttribute('aria-labelledby', 'pcTitle');
  var stars = '';
  for (var i = 0; i < 26; i++){ var s = 3 + (i * 37 % 9); stars += '<span class="pc-star" style="left:' + (i * 61 % 100) + '%;top:' + (i * 37 % 100) + '%;width:' + s + 'px;height:' + s + 'px;animation-delay:-' + (i % 5) + 's"></span>' }
  root.innerHTML =
    '<div class="pc-sky" aria-hidden="true">' + stars + '</div>' +
    '<header class="pc-top"><div><p class="pc-eyebrow">Geheimes Easter Egg ✦</p><h2 id="pcTitle">Palins Zauberküche</h2></div>' +
      '<button class="pc-close" type="button" aria-label="Spiel schließen"><svg width="16" height="16" viewBox="0 0 16 16" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M3 3l10 10M13 3L3 13"/></svg></button></header>' +
    '<div class="pc-main">' +
      '<section class="pc-stage">' +
        '<p class="pc-count"><b id="pcN">0</b><span>Essenties</span></p>' +
        '<p class="pc-rate" id="pcRate">0 pro Sekunde</p>' +
        '<button class="pc-orb" type="button" id="pcOrb" aria-label="Essenties zaubern"><img src="img/platzhalter/essenties.svg" alt="" draggable="false"></button>' +
        '<p class="pc-hint" id="pcHint">Tipp auf die Dose, um Essenties zu zaubern.</p>' +
      '</section>' +
      '<section class="pc-shop" aria-label="Upgrades"><p class="pc-shop-title">Zauber-Upgrades</p><div id="pcShop"></div>' +
        '<button class="pc-reset" type="button" id="pcReset">Spielstand zurücksetzen</button></section>' +
    '</div>';

  var shop = root.querySelector('#pcShop'), nEl = root.querySelector('#pcN'), rateEl = root.querySelector('#pcRate'), orb = root.querySelector('#pcOrb'), hint = root.querySelector('#pcHint');
  shop.innerHTML = UP.map(function(u){
    var pic = u.img ? '<img src="' + u.img + '" alt="">' : u.icon;
    return '<button class="pc-up" type="button" data-up="' + u.id + '"><span class="pc-up-ic">' + pic + '</span>' +
      '<span class="pc-up-txt"><b>' + u.name + '</b><small>' + u.desc + '</small></span>' +
      '<span class="pc-up-meta"><span class="pc-cost"></span><span class="pc-own"></span></span></button>';
  }).join('');
  var upBtns = {};
  shop.querySelectorAll('.pc-up').forEach(function(b){ upBtns[b.dataset.up] = b });

  function paint(){
    nEl.textContent = fmt(st.n);
    rateEl.textContent = fmt(perSec()) + ' pro Sekunde' + (boost() > 1 ? ' · ✦ 7-fach!' : '');
    UP.forEach(function(u){
      var b = upBtns[u.id], c = cost(u), done = u.once && own(u.id);
      var seen = st.total >= u.base * .4 || own(u.id);          // Upgrades tauchen erst nach und nach auf
      b.hidden = !seen;
      b.disabled = done || st.n < c;
      b.querySelector('.pc-cost').textContent = done ? '✓' : fmt(c) + ' ✦';
      b.querySelector('.pc-own').textContent = u.once ? '' : (own(u.id) ? own(u.id) + '×' : '');
    });
    root.classList.toggle('boosted', boost() > 1);
  }
  function gain(x){
    st.n += x; st.total += x;
    while (st.miles < MILES.length && st.total >= MILES[st.miles][0]){ toast('✦ ' + MILES[st.miles][1]); st.miles++ }
  }

  orb.addEventListener('pointerdown', function(e){
    var v = perClick(); gain(v);
    orb.classList.remove('pop'); void orb.offsetWidth; orb.classList.add('pop');
    var f = d.createElement('span'); f.className = 'pc-float'; f.textContent = '+' + fmt(v);
    f.style.left = e.clientX + 'px'; f.style.top = e.clientY + 'px';
    root.appendChild(f); setTimeout(function(){ f.remove() }, 900);
    if (Math.random() < .35) spark(e.clientX, e.clientY, {n:5, r:40, size:7});
    hint.hidden = true;
    paint();
  });
  shop.addEventListener('click', function(e){
    var b = e.target.closest('.pc-up'); if (!b || b.disabled) return;
    var u = UP.filter(function(x){ return x.id === b.dataset.up })[0], c = cost(u);
    if (st.n < c) return;
    st.n -= c; st.own[u.id] = own(u.id) + 1;
    var r = b.getBoundingClientRect(); spark(r.left + 30, r.top + r.height / 2, {n:12, r:60});
    save(); paint();
  });
  root.querySelector('#pcReset').addEventListener('click', function(){
    if (!confirm('Spielstand wirklich zurücksetzen?')) return;
    st = {n:0, total:0, own:{}, miles:0}; save(); paint(); hint.hidden = false;
  });

  /* golden shooting star: catch it for a 7x boost */
  var starEl = null, starTimer = 0;
  function planStar(){ clearTimeout(starTimer); starTimer = setTimeout(spawnStar, 35000 + Math.random() * 50000) }
  function spawnStar(){
    if (!open) return;
    starEl = d.createElement('button'); starEl.type = 'button'; starEl.className = 'pc-gold'; starEl.setAttribute('aria-label', 'Sternschnuppe fangen');
    starEl.style.top = (15 + Math.random() * 55) + '%';
    starEl.addEventListener('click', function(){
      boostUntil = Date.now() + 12000;
      var r = starEl.getBoundingClientRect(); spark(r.left + r.width / 2, r.top + r.height / 2, {n:24, r:110});
      toast('✦ Sternschnuppe! 12 Sekunden 7-fache Magie');
      starEl.remove(); starEl = null; paint();
    });
    root.appendChild(starEl);
    setTimeout(function(){ if (starEl){ starEl.remove(); starEl = null } planStar() }, 9000);
  }

  /* loop: only runs while the game is open */
  var open = false, last = 0, raf = 0, saveTimer = 0;
  function loop(t){
    if (!open) return;
    var dt = last ? Math.min(1, (t - last) / 1000) : 0; last = t;
    var ps = perSec(); if (ps) gain(ps * dt);
    if (!loop.f || t - loop.f > 120){ loop.f = t; paint() }
    raf = requestAnimationFrame(loop);
  }
  function onKey(e){ if (e.key === 'Escape') close() }
  function show(){
    if (!root.isConnected) d.body.appendChild(root);
    open = true; last = 0; paint();
    root.classList.add('open'); d.documentElement.style.overflow = 'hidden';
    raf = requestAnimationFrame(loop);
    saveTimer = setInterval(save, 5000); planStar();
    d.addEventListener('keydown', onKey);
    setTimeout(function(){ orb.focus({preventScroll:true}) }, 50);
  }
  function close(){
    open = false; cancelAnimationFrame(raf); clearInterval(saveTimer); clearTimeout(starTimer); save();
    root.classList.remove('open'); d.documentElement.style.overflow = '';
    d.removeEventListener('keydown', onKey);
  }
  root.querySelector('.pc-close').addEventListener('click', close);

  window.PalinClicker = {open: show};
})();
